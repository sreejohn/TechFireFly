import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import TextField from 'material-ui/TextField';
import $ from 'jquery';
class Login extends Component {
	constructor(props) {
		super(props);
		//	DelPinCode = "";
		this.state = {
			password: '',
			floatingTextColor: { color: 'white' },
			floatingUserTextColor: { color: 'white' },
			floatingPwdTextColor: { color: 'white' },
		}
		this.handleKeyPress = this.handleKeyPress.bind(this)
	}
	handleKeyPress(event) {
		if (event.key === 'Enter') {
			//alert('Enter pressed')
			this.Login(event)
		}
	}

	Login() {
		document.getElementById('load').style.visibility = 'visible';

		var username = $("#username").val();
		var userpassword = $("#userpassword").val();
		var useremail = $("#useremail").val();
		var checkMandatoryFieldsInPassword = 0;

		if (username === "") {
			document.getElementById('load').style.visibility = 'hidden';
			$("#usernamereq").focus();
			$('#usernamereq').css({
				'display': 'block'
			});
			checkMandatoryFieldsInPassword++;
		} else {
			document.getElementById('load').style.visibility = 'hidden';
			$('#usernamereq').css({
				'display': 'none'
			});
		}

		//alert(userpassword)

		if (userpassword === "") {
			document.getElementById('load').style.visibility = 'hidden';
			$("#passwordreq").focus();
			$('#passwordreq').css({
				'display': 'block'
			});
			checkMandatoryFieldsInPassword++;
		} else {
			document.getElementById('load').style.visibility = 'hidden';
			$('#passwordreq').css({
				'display': 'none'
			});
		}

		if (useremail === "") {
			document.getElementById('load').style.visibility = 'hidden';
			$("#emailreq").focus();
			$('#emailreq').css({
				'display': 'block'
			});
			checkMandatoryFieldsInPassword++;
		} else {
			document.getElementById('load').style.visibility = 'hidden';
			$('#emailreq').css({
				'display': 'none'
			});
		}
		if (checkMandatoryFieldsInPassword !== 0) {

			document.getElementById('load').style.visibility = 'hidden';
			return false;
		}
		var checkcontactname = true;


		var usernamelength = username.length;
		if (usernamelength > 50) {
			checkcontactname = false;

			$("#usernamelength").focus();
			$('#usernamelength').css({
				'display': 'block'
			});
			return;
		}
		if (usernamelength < 8) {
			checkcontactname = false;
			$('#usernamelength').css({
				'display': 'block'
			});
			return;
		}
		if (usernamelength <= 50 || usernamelength >= 8) {
			checkcontactname = true;
			$('#usernamelength').css({
				'display': 'none'
			});
		}

		var Exp = /^(?=.*[0-9])[a-zA-Z0-9!@#$%^&*]{7,15}$/
		if (!username.match(Exp)) {
			$("#usernameaplha").focus();
			$('#usernameaplha').css({
				'display': 'block'
			});
			return;
		}
		else {
			$('#usernameaplha').css({
				'display': 'none'
			});
		}
		var checkcontactpwd = true;
		var passw = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$/

		if (!userpassword.match(passw)) {
			checkcontactpwd = false;
			$("#passwordlength").focus();
			$('#passwordlength').css({
				'display': 'block'
			});
			return;
		}
		else {
			checkcontactpwd = true;
			$('#passwordlength').css({
				'display': 'none'
			});
		}

		var checkemail = true;
		if (useremail !== "")
			var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		if (useremail.match(mailformat)) {
			$('#validemail').css({
				'display': 'none'
			});
			checkemail = true;


		}
		else {


			$('#validemail').css({
				'display': 'block'
			});
			document.getElementById('load').style.visibility = 'hidden';
			checkemail = false;
			return true;
		}
		//alert(checkcontactpwd+"checkcontactname>>"+checkcontactname+"@"+checkemail)

		if (checkemail && checkcontactname && checkcontactpwd) {
			let objUsers = {};
			objUsers.UserName = username;
			objUsers.UserPassword = userpassword;
			objUsers.UserEmail = useremail;
			document.cookie = JSON.stringify(objUsers);
			localStorage.setItem('Users', JSON.stringify(objUsers));
			this.props.history.push("/Home");
		}
	}
	render() {
		return (<div className="bg1">
			<div className="innerborder" style={{ display: "block", marginTop: "5px" }}>
				<MuiThemeProvider><div>
					<TextField floatingLabelFocusStyle={styles.floatingLabelFocusStyle} style={{ marginLeft: "5%", fontSize: "16px", width: "90%" }} underlineStyle={styles.underlineStyle}
						type="text" floatingLabelStyle={this.state.floatingTextColor}
						id="username" autoComplete='off' multiLine
						floatingLabelText="User Name *"
						onKeyPress={(event) => this.handleKeyPress(event)}
						onChange={(event, newValue) => this.setState({ username: newValue })}
					/>
					<p id="usernamereq" style={usernamemandatory}>User Name required</p>
					<p id="usernameaplha" style={usernamemandatory}>User Name should be alpha numeric</p>
					<p id="usernamelength" style={usernamemandatory}>User Name should be maximum of 50 characters and minimum of 8 characters</p>

					<TextField floatingLabelFocusStyle={styles.floatingLabelFocusStyle} underlineStyle={styles.underlineStyle}
						type="text" class="pwd"
						id="userpassword"
						style={{ marginLeft: "5%", fontSize: "16px", width: "90%" }}
						onKeyPress={(event) => this.handleKeyPress(event)} autoCapitalize="none"
						floatingLabelStyle={styles.floatingLabelFocusStyle} floatingLabelText="Password *" autoComplete='off' value={this.state.password}
						onChange={(event, newValue) => this.setState({ password: newValue })}
					/>
					<p id="passwordreq" style={usernamemandatory}>Password required</p>
					<p id="passwordlength" style={usernamemandatory}>Password should be maximum of 50 characters and minimum of 8 characters
					,also there should be atleast one Special Character and one Numeric Value
					</p>


					<TextField floatingLabelFocusStyle={styles.floatingLabelFocusStyle} style={{ marginLeft: "5%", fontSize: "16px", width: "90%" }} underlineStyle={styles.underlineStyle}
						type="email" floatingLabelStyle={this.state.floatingTextColor}
						id="useremail" autoComplete='off' multiLine
						floatingLabelText="Email *"
						onKeyPress={(event) => this.handleKeyPress(event)}
						onChange={(event, newValue) => this.setState({ useremail: newValue })}
					/>
					<p id="emailreq" style={usernamemandatory}>Email required</p>
					<p id="validemail" style={usernamemandatory}>Email should be a valid Email ID</p>
					<br></br>

					<div className="LOgin"  >
						<button type="submit" className="loginoutline" onClick={(event) => this.Login(event)}>Sign in &nbsp;
									</button>
					</div>
					<br></br>

					<div id="load" className="loader"></div>

				</div>
				</MuiThemeProvider>
			</div>
		</div>
		);
	}
}

const styles = {
	floatingLabelFocusStyle: {
		color: "white",
	}, underlineStyle: {
		borderBottomColor: "white",
	}, floatingTextColor: { color: 'red' }
}
const usernamemandatory = {
	"marginBottom": "-1%",
	"marginLeft": "5%",
	fontSize: "12px",
	"width": "80%", color: "red", display: "none"
};
export default Login;
import React from "react";
import search from '../../assets/iconssearch.png';
import { stockData } from "./data";
import { Component } from 'react';
import _ from 'lodash';




class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {
            menutype: "Mountain",
            stocks: [],
            search: ""
        }
    }
    selectMenuType(type) {
        var data = _.filter(stockData[0].content, { type: type });
     //   setTimeout(() => {
            this.setState({ stocks: data, menutype: type,search: ""});
       // }, 50);
    }
    componentDidMount() {
        var header = document.getElementById("outer");
        var btns = header.getElementsByClassName("msgBtn");
        for (var i = 0; i < btns.length; i++) {
            btns[i].addEventListener("click", function () {
                var current = document.getElementsByClassName("active");
                current[0].className = current[0].className.replace(" active", "");
                this.className += " active";
            });
        }
        var data = _.filter(stockData[0].content, { type: this.state.menutype });
        this.setState({ stocks: data })
    }

    // Search input   
    onInput = e => this.setState({ [e.target.id]: e.target.value, menutype: "Seached " });
    onFocus = e => e.target.parentNode.parentNode.classList.add('focus');
    onBlur = e => e.target.parentNode.parentNode.classList.remove('focus');
    


    showImages(data, menutype) {
       // console.log(JSON.stringify(data)+">>>>>>>>>."+menutype)
        if (menutype === "all") {
            return <div className="row">
                {data.map((data, key) => {
                    return (<div className="column" key={key}  >

                        <Stock
                            src={data.posterimage}
                        />

                    </div>
                    );
                })}

            </div>
        }
        else {
            return <div className="row">
                {data.map((data, key) => {
                    return (<div className="column" key={key}  >
                        {menutype === data.type ?
                            <Stock
                                src={data.posterimage}
                            />
                            : ""}
                    </div>
                    );
                })}

            </div>
        }
    }
    render() {
        let filtered = stockData[0].content.filter(item => item.name.toLowerCase().includes(this.state.search.toLowerCase()));
        return (
            <div>
                <div>
                    <div className="search">
                        <input
                            id="search"
                            type="search"
                            value={this.state.search}
                            placeholder="Search..."
                            onChange={this.onInput}
                            onFocus={this.onFocus}
                            onBlur={this.onBlur}
                            autoComplete="off"
                            style={{ backgroundImage: `url(${search})`, backgroundRepeat: "no-repeat", backgroundPosition: "10px 8px" }}
                        />
                        <i className="fas fa-search" style={{ color: "black" }}></i>
                    </div>

                    <div id="outer">
                        <div className="inner"><button className="msgBtn active" id="Mountain" onClick={(e) => this.selectMenuType("Mountain")}>Mountain</button></div>
                        <div className="inner"><button className="msgBtn" id="Beaches" onClick={(e) => this.selectMenuType("Beaches")}>Beaches</button></div>
                        <div className="inner"><button className="msgBtn" id="Birds" onClick={(e) => this.selectMenuType("Birds")}>Birds</button></div>
                        <div className="inner"><button className="msgBtn" id="Food" onClick={(e) => this.selectMenuType("Food")}>Food</button></div>
                    </div>
                    <div className="stock-container">

                        <h2 className="headername">{this.state.menutype} Pictures</h2>
                        {this.state.search === "" && this.state.stocks.length !== 0 ?
                            this.showImages(this.state.stocks, this.state.menutype)
                            : null}
                        {this.state.search !== "" && filtered.length > 0 ? (
                            this.showImages(filtered, "all")
                        ) : null}
                        {this.state.search !== "" && filtered.length === 0 ? (<div className="NoImageTxt">
                            <span className="Nodatafoundtxt">No images found with  </span>
                            <span className="Nodatafoundtxt" style={{color:"blue"}}>
                                {this.state.search}
                            </span></div>
                        ) : null}

                    </div>

                </div>
            </div>
        );
    }
}






class Stock extends Component {

    render() {
        // const { company, posterimage } = this.props;
        // if (!company) return <div />;
        return (
            <img className="RoundImage1" alt={this.props.src} src={this.props.src} ></img>

        );
    }
}

export default Home;



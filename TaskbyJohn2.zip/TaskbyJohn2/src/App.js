import React from 'react';
import './App.css';
import Home from './views/Stocks';
import Login from './views/Login';
import { HashRouter, Route, Switch } from 'react-router-dom';
function App() {
  return (
    <HashRouter>
      <Switch>
            <Route exact path="/" component={Login} />
            <Route path="/Home" component={Home} />
      </Switch></HashRouter>
  );
}

export default App;

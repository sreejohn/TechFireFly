Please create a Login Page and it would  have lables user name ,password and email id  along with text boxes .

Please add the validations of each field and save those values in Cookie 

User Name should be Alphanumeric and it has maximum of 50 characters and minimum of 8 characters

Password should be Alphanumeric and it has maximum of 50 characters and minimum of 8 characters ,Also There should be atleast one Special Character and one Numeric Value .

Email should be a valid Email ID .

Once the Validation is completed please all the values in Cookie .



After you saving the values on the then it should route to /Home 

/Home  should contain following design


It has 4 buttons 
1.Mountain
2.Beaches
3.Birds
4.Food

On initial you should show Mountain Images and Mountain Button Should be Bold or selected mode.

When user click on Beaches it should show Beaches Images and Beach Button Should be Bold or selected mode
When user click on Birds it should show Birds  Images and Birds Button Should be Bold or selected mode
When user click on Food it should show Food Images   and Food Button Should be Bold or selected mode
When user click on Mountain it should show Mountain Images  and Mountain Button Should be Bold or selected mode

All Images were saved "Assets/Images" Folder  (Images folder you have sub folder ) .

Similarly when User searches Mountain you should show Mountain Images  
Similarly when User searches Food you should show Food Images  


If user searches other than above 4 items then you should display No Images .

For example user searches Forest then you should show no images






